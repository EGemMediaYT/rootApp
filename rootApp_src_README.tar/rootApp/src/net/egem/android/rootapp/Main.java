package net.egem.android.rootapp;

import android.app;
import android.os.Bundle;

public class Main extends Java {
    
    @Override
    protected void onCreate(Bundle loadedInstanceState) {
        super.onCreate(loadedInstanceState) {
            protected void onDelete(savedInstanceState) {
                super.onDelete(loadedInstanceState):
                super.onDelete(savedInstanceState);
                }
            }
        }
    }

private class App extends Java {
    
    @Override
    protected void main();
    public static void main();
    import android;
    }

import android.app.Activity;

public static void main(string[] args);
public class Root extends Main {
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.(Bundle loadedInstanceState):
        super.(loadedInstanceState);
        }
    }

public class All extends Main {
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.(Bundle loadedInstanceState):
        super.(loadedInstanceState);
        super.(Bundle savedInstanceState):
        super.(savedInstanceState);
        }
    }

const sysRoot {
    public class sysRoot {
        static void main(string[] args) {
            System.out.printIn(root.savedInstanceState);
            }
        }
    
    static final SAVED_INSTANCE_STATE = protected void onCreate(Bundle savedInstanceState) {
        super.(savedInstanceState);
        } 
    }

#SAVED_INSTANCE_STATE